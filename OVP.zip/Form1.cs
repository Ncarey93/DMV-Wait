﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DMV_WaitNote
    //Nicholas Carey/ 3.18.23/ MS539/ Estimated Time to Finish = 3 Hours. Act. Time to finish = +4/
{
    public partial class Form1 : Form
    {
        public static Form1 instance;
        public TextBox tb1;
        public Form1()
        {
            InitializeComponent();
            instance = this;
            tb1 = new TextBox();
            


            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("We know you! Enter Address!");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Sorry, we're on break, please select another time.");
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ERROR:User may not leave!");
        }

        private void toolTip1_Popup_1(object sender, PopupEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
         linkLabel1.LinkVisited = true;
         System.Diagnostics.Process.Start("https://www.mcdonalds.com/us/en-us.html");
            {

            }  

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("We know your address, Now Go To Next Page!");
        }
    }
}
