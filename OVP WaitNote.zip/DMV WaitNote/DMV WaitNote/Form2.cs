﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//second page is for displaying Menu Strip,TryParse, & Catch.. Adding the transition to form 1 to form 2 took most of the day 3.25.23.
namespace DMV_WaitNote
{
    public partial class Form2 : Form
    {
        int num1;
        public static Form2 instance;
        public Form2()
        {
            InitializeComponent();
            instance = this;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1.instance.tb1.Text = "set by form2";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("There is No Going Back!");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Sorry, we're on break, please select another time.");
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out num1))
                MessageBox.Show("Total Mileage =" + num1);
            else
            { MessageBox.Show("You Cannot Fool the Party!"); }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                num1 = int.Parse(textBox2.Text);
            }
            catch (Exception )
            {
                MessageBox.Show("Invalid Entry");
            }
            {

                if (int.TryParse(textBox2.Text, out num1))
                    MessageBox.Show("Gov. Rationed Fuel =" + num1);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            

            
        }
    }
}








